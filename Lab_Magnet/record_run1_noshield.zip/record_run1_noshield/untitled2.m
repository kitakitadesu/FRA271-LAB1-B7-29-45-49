function volt = raw_to_volt(raw)
volt = raw / 4095 * 3.3;
end

%% 

no_magnet=load("./nomagnet.mat").data{1}.Values.Data
mean_no_magnet_raw=mean(no_magnet)
no_magnet_voltage=raw_to_volt(mean_no_magnet_raw)


%% 

% Display the calculated voltage
disp(['Voltage with no magnet: ', num2str(no_magnet_voltage), ' V']);

%% North magnet: mean voltage vs distance
[distN, voltN] = magnet_curve("dirtymagnet_north", "dirtymagnet");
figure; plot(distN, voltN, 'r-o','LineWidth',2); hold on;
yline(no_magnet_voltage, '--k', 'No magnet', 'LineWidth', 2);
yline(3.3/2, '-', 'Vcc/2', 'Color', [0 0.45 0], 'LineWidth', 2);
legend('North', 'No magnet', 'Vcc/2');
xlabel('Distance (cm)'); ylabel('Mean voltage (V)');
title('North magnet');
xlim([1 4.5]); xticks(1:0.5:4.5);        % major: 0.5 cm
set(gca, 'XMinorTick', 'on');            % minor: 0.1 cm (5 per major)
grid on; grid minor;
set(gca, 'GridAlpha', 0.5, 'MinorGridAlpha', 0.2);
set(gca, 'LineWidth', 1.5, 'FontSize', 14);

%% South magnet: mean voltage vs distance
[distS, voltS] = magnet_curve("cleanmagnet_south", "cleanmagnet");
figure; plot(distS, voltS, 'b-o','LineWidth',2); hold on;
yline(no_magnet_voltage, '--k', 'No magnet', 'LineWidth', 2);
yline(3.3/2, '-', 'Vcc/2', 'Color', [0 0.45 0], 'LineWidth', 2);
legend('South', 'No magnet', 'Vcc/2');
xlabel('Distance (cm)'); ylabel('Mean voltage (V)');
title('South magnet');
xlim([1 4.5]); xticks(1:0.5:4.5);        % major: 0.5 cm
set(gca, 'XMinorTick', 'on');            % minor: 0.1 cm (5 per major)
grid on; grid minor;
set(gca, 'GridAlpha', 0.5, 'MinorGridAlpha', 0.2);
set(gca, 'LineWidth', 1.5, 'FontSize', 14);

%% Both on one plot
figure; plot(distN, voltN, 'r-o', distS, voltS, 'b-s','LineWidth',2); hold on;
yline(no_magnet_voltage, '--k', 'LineWidth', 2);
yline(3.3/2, '-', 'Vcc/2', 'Color', [0 0.45 0], 'LineWidth', 2);
xlabel('Distance (cm)'); ylabel('Mean voltage (V)');
title('North vs South magnet'); legend('North', 'South', 'No magnet', 'Vcc/2');
xlim([1 4.5]); xticks(1:0.5:4.5);        % major: 0.5 cm
set(gca, 'XMinorTick', 'on');            % minor: 0.1 cm (5 per major)
grid on; grid minor;
set(gca, 'GridAlpha', 0.5, 'MinorGridAlpha', 0.2);
set(gca, 'LineWidth', 1.5, 'FontSize', 14);

%%
function [dist, volt] = magnet_curve(folder, suffix)
files = dir(fullfile(folder, "*-" + suffix + ".mat"));
n = numel(files);
dist = zeros(n,1); volt = zeros(n,1);
for k = 1:n
    tok = regexp(files(k).name, '^(\d+(?:\.\d+)?)-', 'tokens');
    dist(k) = str2double(tok{1});
    d = load(fullfile(files(k).folder, files(k).name));
    volt(k) = raw_to_volt(mean(d.data{1}.Values.Data(:)));
end
[dist, i] = sort(dist); volt = volt(i);
end 
